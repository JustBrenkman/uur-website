declare var module: {id: string};

### Platform

A set of utilities that gather information about the current
platform and the different features it supports.

<!-- example(cdk-platform-overview) -->

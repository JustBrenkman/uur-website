### Coercion

Utility functions for coercing `@Input`s into specific types.

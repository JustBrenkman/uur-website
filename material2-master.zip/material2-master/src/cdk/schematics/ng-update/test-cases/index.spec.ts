/** Path to the schematic collection that includes the migrations. */
export const migrationCollection = require.resolve('../../migration.json');

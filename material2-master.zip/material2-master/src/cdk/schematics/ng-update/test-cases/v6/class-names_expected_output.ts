import {CdkConnectedOverlay, CdkOverlayOrigin} from '@angular/cdk/overlay';
import {CdkObserveContent} from '@angular/cdk/observers';
import {CdkTrapFocus} from '@angular/cdk/a11y';

const a = new CdkConnectedOverlay();
const b = new CdkOverlayOrigin();
const c = new CdkObserveContent();
const d = new CdkTrapFocus();

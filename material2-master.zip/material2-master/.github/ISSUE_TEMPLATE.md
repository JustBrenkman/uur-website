#### Bug, feature request, or proposal:


#### What is the expected behavior?


#### What is the current behavior?


#### What are the steps to reproduce?
Providing a StackBlitz reproduction is the *best* way to share your issue. <br/>
StackBlitz starter: https://goo.gl/wwnhMV<br/>


#### What is the use-case or motivation for changing an existing behavior?


#### Which versions of Angular, Material, OS, TypeScript, browsers are affected?


#### Is there anything else we should know?
